Alex Kaiser
Tmax = 5
No Bonus

