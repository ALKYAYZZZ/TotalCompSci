Alex Kaiser
No Downloaded Code
Attempted glfwGetTime() Bonus and Textured Ground Bonus
