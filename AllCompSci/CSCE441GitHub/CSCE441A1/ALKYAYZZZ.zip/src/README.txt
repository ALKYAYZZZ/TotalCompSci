Alex Kaiser
Two colors for mode 2 are pink at the bottom and red at the top
Formula for barycentric coordinates obtained from https://gamedev.stackexchange.com/questions/23743/whats-the-most-efficient-way-to-find-barycentric-coordinates
