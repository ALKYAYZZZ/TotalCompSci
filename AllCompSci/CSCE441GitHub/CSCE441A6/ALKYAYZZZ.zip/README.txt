Alex Kaiser
�The mesh was initially created using Cosmic Blobs software developed by Dassault Systemes SolidWorks Corp.�
Completed all stages including bonus.
After compilation, program will take around 2 min to execute due to time complexity of calculating skinned verticies.
